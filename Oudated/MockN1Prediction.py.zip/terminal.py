import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

fires = pd.read_csv("cleaned_forest_fires.csv")
weather = pd.read_csv("cleaned_weather_data_2001-2021.csv")

import datetime
province_input = input("Enter province name (e.g. Malaga): ").strip().lower()

print("fires columns:", fires.columns)
fires["date"] = pd.to_datetime(fires["detection"], dayfirst=True)
weather["DATE"] = pd.to_datetime(weather["DATE"])

fires["merge_date"] = fires["date"].dt.date
weather["merge_date"] = weather["DATE"].dt.date

df = pd.merge(fires, weather, on="merge_date", how="inner")

if "surface_losses" in df.columns:
    df["severe_fire"] = (df["surface_losses"] > 10).astype(int)
else:
    raise KeyError("error")

features = ["TAVG", "TMAX", "TMIN", "PRCP", "ELEVATION"]
df = df.dropna(subset=features + ["severe_fire"])

X = df[features]
y = df["severe_fire"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=0)

model = LogisticRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)


print(f"\nPredictions for last 10 days available in province '{province_input.title()}':")

province_weather = weather[weather["NAME"].str.lower().str.contains(province_input)].sort_values("DATE", ascending=False).head(10)

if province_weather.empty:
    print("No weather record.")
else:
    for _, row in province_weather.iterrows():
        features_input = np.array([[row["TAVG"], row["TMAX"], row["TMIN"], row["PRCP"], row["ELEVATION"]]])
        features_scaled = scaler.transform(features_input)
        pred = model.predict(features_scaled)[0]
        prob = model.predict_proba(features_scaled)[0][1]
        print(f"{row['DATE'].date()}: {'HIGH' if pred == 1 else 'LOW'}")